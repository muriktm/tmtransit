
        <span class="errors" style="color: red;"><?php echo $err; ?></span>
        <div id="order" class="col-sm-4">
        	<form action="index.php" method="post">
            	<h4>Опишите Вашу проблему</h4>
            	<div class="form-group">
            		<textarea class="top-form" name="description" rows="4" placeholder="Опишите Вашу проблему и мы с вами свяжемся в течении 5 минут"></textarea>
            	</div>
            	<div class="form-group">
            		<input class="top-form" type="text" name="username" placeholder="Ваше имя">
            	</div>
            	<div class="form-group">
            		<input class="top-form" type="text" name="userphone" placeholder="Ваш номер телефона">
            	</div>
            	<div class="form-group">
            		<button type="submit" name="add" class="btn">отправить</button>
            	</div>
        	</form>
        </div>
<?php require_once "head.php"; ?>

  <body>
    <div class="navbar">
      <div id="header">
        <div class="container">
          <a class="logo" href=".">логотип</a>
          <span class="phone">+8888888888</span>
        </div> 
      </div>
    </div>


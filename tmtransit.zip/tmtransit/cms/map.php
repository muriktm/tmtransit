

          <div id="map">
          	<div class="row map">
          	  <div class="col-sm-12">
          	  	<ul class="unstyled">
          	  	  <li><a href="#order">Сделать заказ</a></li>
          	  	  <li><a href="#pref">Наши преимущества</a></li>
          	  	  <li><a href="#how">Как мы это делаем</a></li>	
          	  	  <li><a href="#team">Наша команда</a></li>
          	  	</ul>
          	  	<fieldset id="address">
          	  		<legend>Наши контакты</legend>
          	  		<p>г. Ашхабад, ул. Кемине, 24</p>
          	  		<p>тел: +888888888</p>
          	  	</fieldset>
          	  </div>
          	</div>
          </div>

          </div>
      </div>
    </div>
    <?php require_once "footer.php"; ?>
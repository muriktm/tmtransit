
    <div id="main">
      <div class="container">
        <div class="content row">
        <div class="col-sm-8">
          <div id="slider" class="carousel slide">
            <div class="carousel-inner">
              <div class="active item">
                <img src="img/banner1.png" alt="Гарантия 5 дней на заправленные картриджы">
              </div>
              <div class="item">
                <img src="img/banner2.png" alt="Доставка клиенту бесплатно">
              </div>
              <div class="item">
                <img src="img/banner3.png" alt="Скидки для постоянных клиентов">
              </div>
            </div>
            <!-- Навигационные элементы -->
            <a class="carousel-control left" href="#slider" data-slide="prev">&lsaquo;</a>
            <a class="carousel-control right" href="#slider" data-slide="next">&rsaquo;</a>
          </div>
        </div>

        <?php require_once "order.php"; ?>

        </div>
          <div class="row">
          
          <div id="pref">
            <h4>Наши преимущества</h4>
            <div class="row">
              <div class="col-sm-4">
                <div class="panel">
                  <h4>Гибкость работы</h4>
                  <label>В случаи проблемы мы работаем сверхурочно</label>
                </div>
                <div class="panel">
                  <h4>Скидки</h4>
                  <label>Постоянные скидки для наших клиентов</label>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="panel">
                  <h4>Гарантия</h4>
                  <label>Мы даем гарантию нашего сервиса</label>
                </div>
                <div class="panel">
                  <h4>Срочная заправка</h4>
                  <label>Если что то срочно, мы заправим вне очереди</label>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="panel">
                  <h4>Дешевая стоимость</h4>
                  <label>Самые низкие цены в Ашхабаде</label>
                </div>
                <div class="panel">
                  <h4>Специалисты</h4>
                  <label>У нас только сертифицированные инженеры</label>
                </div>
              </div>
            </div>
          </div>

          <div id="how">
            <h3>Как мы это делаем</h3>
            <div class="info row">
              <div class="col-md-12">
                <div class="servise">
                  <img src="img/list.png">
                  <label>Оставьте заявку</label>
                </div>
                <div class="servise">
                  <img src="img/bike.png">
                  <label>мы забираем картридж</label>
                </div>
                <div class="servise">
                  <img src="img/cogs.png">
                  <label>мы заправляем</label>
                </div>
                <div class="servise">
                  <img src="img/money.png">
                  <label>вы оплачиваете</label>
                </div>
                <div class="servise">
                  <img src="img/printer.png">
                  <label>используете картридж</label>
                </div>
                <div class="arrow">
                  <i class="fa fa-arrow-right fa0"></i>
                </div>
              </div>
            </div>
          </div>

          <div id="team">
          	<h3>Наша команда</h3>
          	<div class="row members">
          	  <div class="col-sm-3">
          	  	<img class="member" src="img/anonim.png">
          	  </div>
          	  <div class="col-sm-3">
          	  	<img class="member" src="img/anonim.png">
          	  </div>
          	  <div class="col-sm-3">
          	  	<img class="member" src="img/anonim.png">
          	  </div>
          	  <div class="col-sm-3">
          	  	<img class="member" src="img/anonim.png">
          	  </div>
          	</div>
          </div>

    <?php require_once "map.php"; ?>
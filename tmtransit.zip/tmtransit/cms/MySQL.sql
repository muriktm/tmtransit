
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- База данных: `order`
--
CREATE DATABASE `order` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `order`;

-- --------------------------------------------------------

--
-- Структура таблицы `problems`
--

CREATE TABLE IF NOT EXISTS `problems` (
  `description` text NOT NULL,
  `username` varchar(255) NOT NULL,
  `userphone` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


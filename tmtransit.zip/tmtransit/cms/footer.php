
    <footer class="footer">
    	<div class="container">
    		<label>Дизайн сайта разработал: CompanyName</label>
    		<label class="copyright">© 2017 domain.tm</label>
    	</div>
    </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script>
      //слайдер в описании
      $(".carousel").carousel({interval:3000});
      //стрелки "Как мы это делаем"
      $(".fa0").css("left", 128);
      for (var i = 1; i < 4; i++) {
        var width = 128;
        width = width + 144*i;
        $(".arrow").append('<i class="fa fa-arrow-right" style="left:'+width+'px"></i>');
      }
    </script>
  </body>
</html>
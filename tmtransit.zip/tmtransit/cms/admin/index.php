﻿<?php
	mb_internal_encoding('UTF-8');
	require_once "../config.php";

	$connect = mysql_connect($db_hostname, $db_username, $db_password);
	if (!$connect) die("Connect error: " . mysql_error());

	mysql_select_db($db_database, $connect)
		or die("DB not found: ".mysql_error());

	$sql = "SELECT * FROM problems";
	$result = mysql_query($sql);

	if (!$result) die("Error getting list");

	$rows = mysql_num_rows($result);

?>
<?php require_once "head.php"; ?>
<body>
<div class="container">
	<table class="table table-striped">
		<thead>
		<tr>
			<td>Описание проблемы</td>
			<td>Имя заказчика</td>
			<td>Номер телефона</td>
		</tr>
		</thead>
		<?php
			for ($i=0; $i < $rows; $i++) {
				$row = mysql_fetch_row($result);
				echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td></tr>";
			}
		?>
	</table>
</div>
</body>
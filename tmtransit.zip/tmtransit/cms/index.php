﻿<?php
	mb_internal_encoding('UTF-8');

	require_once 'function.php';

	require_once 'header.php';

	require_once "main.php";

?>
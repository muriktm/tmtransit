<?php
	require_once "config.php";

	$connect = new mysqli($db_hostname, $db_username, $db_password, $db_database);
	if ($connect->connect_error) die("Проблема с подключением в Базу Данных ".$connect->connect_error);

	if (isset($_POST['add'])) {
		if ($_POST['description'] != '' && $_POST['username'] != '' && $_POST['userphone'] != '') {
			$desc = $_POST['description'];
			$uname = $_POST['username'];
			$uphone = $_POST['userphone'];

			$err = '';

			if (mb_strlen($uname)>50 || mb_strlen($uname)<2) {
				$err .= 'Недопустимая длина поля Имя<br>';
			}
			if (!preg_match('/^[0-9+-]{1,16}$/su', $uphone)) {
				$err .= 'Неверный номер телефона. Допустимый формат +9936XXXXXXX<br>';
			}

			if ($err == '') {
				$desc = htmlspecialchars($desc, ENT_COMPAT, 'UTF-8');
				$uname = htmlspecialchars($uname, ENT_COMPAT, 'UTF-8');
				$uphone = htmlspecialchars($uphone, ENT_COMPAT, 'UTF-8');
			
				$sql = "INSERT INTO problems VALUES ('$desc', '$uname', '$uphone')";
				$result = $connect->query($sql);
	
				if (!$result) echo "Sorry, connaection error. Try later";
			}
		} else {
			echo "Пожалуйста, заполняйте все поля!";
		}
	}